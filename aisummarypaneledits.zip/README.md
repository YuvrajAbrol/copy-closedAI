AI Summary panel — edits made on top of the uploaded HR-Copilot-main.zip
==========================================================================

These are the exact files added/changed to implement the "Today's briefing"
AI Summary + Suggested Workflow panel on the Intake page. Directory
structure below mirrors the project root, so you can drop these straight
into your existing checkout (overwriting the two modified files).

New files:
  backend/agents/insights.py
  frontend/src/components/ai-summary-panel.tsx

Modified files (full replacement — see ai-summary-panel.patch for a diff
against the original zip's versions):
  backend/api/v1/dashboard.py       (added POST /dashboard/briefing route)
  frontend/src/components/pages/intake-page.tsx   (renders <AiSummaryPanel />)

ai-summary-panel.patch is a unified diff of the same four files, generated
with `git diff`, if you'd rather apply it with `git apply` / `patch -p1`
from the project root instead of copying files by hand.

No new environment variables are required. Setting OPENAI_API_KEY (already
a supported backend var) switches the briefing from the deterministic
heuristic ranking to LLM-generated summaries.
