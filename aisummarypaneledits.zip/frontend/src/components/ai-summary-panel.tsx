"use client"

import { useCallback, useEffect, useMemo, useState } from "react"
import {
  AlertTriangle,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Loader2,
  RefreshCw,
  Sparkles,
  X,
} from "lucide-react"
import { toast } from "sonner"
import { cn } from "@/lib/utils"
import { useNavigation } from "@/lib/navigation"
import type { IntakeItem } from "@/lib/intake-data"

const AUTH_TOKEN_KEY = "auth_token"

function authHeaders(): HeadersInit {
  const token =
    (typeof window !== "undefined" && localStorage.getItem(AUTH_TOKEN_KEY)) || "mock-jwt-token"
  return { Authorization: `Bearer ${token}`, "Content-Type": "application/json" }
}

type WorkflowKind = "priority" | "batch" | "cluster" | "insight"

interface WorkflowEntry {
  kind: WorkflowKind
  label: string
  title: string
  detail: string
  item_ids: string[]
}

interface BriefingResponse {
  generated_at: string
  open_count: number
  needs_judgement_count: number
  counts?: {
    incomplete_onboarding?: number
    open_tickets?: number
    active_applicants?: number
  }
  source: "llm" | "heuristic"
  summary: string
  workflow: WorkflowEntry[]
}

type Status = "loading" | "success" | "error" | "empty"

const KIND_STYLES: Record<WorkflowKind, { badge: string; ring: string }> = {
  priority: { badge: "bg-destructive/15 text-destructive", ring: "border-destructive/20" },
  batch: { badge: "bg-navy/15 text-navy", ring: "border-navy/20" },
  cluster: { badge: "bg-warning/15 text-warning", ring: "border-warning/20" },
  insight: { badge: "bg-success/15 text-success", ring: "border-success/20" },
}

function formatTime(iso: string): string {
  try {
    return new Date(iso).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })
  } catch {
    return ""
  }
}

export function AiSummaryPanel({ items }: { items: IntakeItem[] }) {
  const nav = useNavigation()
  const [status, setStatus] = useState<Status>("loading")
  const [data, setData] = useState<BriefingResponse | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [collapsed, setCollapsed] = useState(false)
  const [dismissed, setDismissed] = useState(false)

  const itemsById = useMemo(() => {
    const map = new Map<string, IntakeItem>()
    for (const it of items) map.set(it.id, it)
    return map
  }, [items])

  const load = useCallback(async () => {
    setStatus("loading")
    setError(null)
    try {
      const payload = {
        items: items.map((it) => ({
          id: it.id,
          subject: it.subject,
          urgency: it.urgency,
          disposition: it.disposition,
          due: it.due,
          age_minutes: it.ageMinutes,
          cluster_id: it.clusterId,
          state: it.state,
          topic: it.topic,
          snippet: it.snippet,
        })),
      }
      const res = await fetch("/api/v1/dashboard/briefing", {
        method: "POST",
        headers: authHeaders(),
        body: JSON.stringify(payload),
      })
      if (!res.ok) {
        const body = await res.json().catch(() => null)
        throw new Error(body?.detail || `Briefing request failed (${res.status})`)
      }
      const json = (await res.json()) as BriefingResponse
      setData(json)
      setStatus(json.open_count === 0 || json.workflow.length === 0 ? "empty" : "success")
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to load today's briefing")
      setStatus("error")
    }
  }, [items])

  useEffect(() => {
    void load()
    // Re-run only when the underlying item set changes, not on every render.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [items.length])

  const goToEntry = useCallback(
    (entry: WorkflowEntry | undefined) => {
      if (!entry || entry.item_ids.length === 0) return
      const target = itemsById.get(entry.item_ids[0])
      if (!target) return
      nav.navigateToClusterDetail(target.clusterId)
    },
    [itemsById, nav],
  )

  const firstEntry = data?.workflow?.[0]
  const batchEntry = data?.workflow?.find((w) => w.kind === "batch")

  if (dismissed) {
    return (
      <button
        type="button"
        onClick={() => setDismissed(false)}
        className="fixed bottom-6 right-6 z-40 inline-flex items-center gap-2 rounded-full border border-border/60 bg-navy px-4 py-2.5 text-[13px] font-medium text-white shadow-lg transition-transform hover:-translate-y-0.5"
      >
        <Sparkles className="size-4" />
        Today&apos;s briefing
      </button>
    )
  }

  return (
    <div className="dream-in fixed bottom-6 right-6 z-40 w-[min(26rem,calc(100vw-3rem))] overflow-hidden rounded-2xl border border-border/60 bg-card shadow-2xl">
      <div className="flex items-center justify-between gap-3 bg-navy px-4 py-3.5 text-white">
        <div className="flex min-w-0 items-center gap-2.5">
          <span className="flex size-7 shrink-0 items-center justify-center rounded-lg bg-white/15">
            <Sparkles className="size-3.5" />
          </span>
          <p className="truncate text-[13.5px] font-semibold">Today&apos;s briefing</p>
        </div>
        <div className="flex shrink-0 items-center gap-1">
          {data?.generated_at && (
            <span className="mr-1 text-[11px] text-white/70">Generated {formatTime(data.generated_at)}</span>
          )}
          <button
            type="button"
            onClick={() => void load()}
            disabled={status === "loading"}
            aria-label="Refresh briefing"
            className="inline-flex size-6 items-center justify-center rounded-md text-white/80 transition-colors hover:bg-white/10 hover:text-white disabled:opacity-50"
          >
            <RefreshCw className={cn("size-3.5", status === "loading" && "animate-spin")} />
          </button>
          <button
            type="button"
            onClick={() => setCollapsed((c) => !c)}
            aria-label={collapsed ? "Expand briefing" : "Collapse briefing"}
            className="inline-flex size-6 items-center justify-center rounded-md text-white/80 transition-colors hover:bg-white/10 hover:text-white"
          >
            {collapsed ? <ChevronUp className="size-3.5" /> : <ChevronDown className="size-3.5" />}
          </button>
          <button
            type="button"
            onClick={() => setDismissed(true)}
            aria-label="Dismiss briefing"
            className="inline-flex size-6 items-center justify-center rounded-md text-white/80 transition-colors hover:bg-white/10 hover:text-white"
          >
            <X className="size-3.5" />
          </button>
        </div>
      </div>

      {!collapsed && (
        <div className="max-h-[70vh] overflow-y-auto p-4">
          {status === "loading" && (
            <div className="space-y-3 py-2">
              <div className="flex items-center gap-2 text-[12.5px] text-muted-foreground">
                <Loader2 className="size-3.5 animate-spin" />
                Analyzing today&apos;s queue…
              </div>
              {[0, 1, 2].map((i) => (
                <div key={i} className="h-14 animate-pulse rounded-lg bg-secondary/60" />
              ))}
            </div>
          )}

          {status === "error" && (
            <div className="flex flex-col items-center gap-2.5 rounded-xl border border-destructive/20 bg-destructive/5 px-4 py-6 text-center">
              <AlertTriangle className="size-5 text-destructive" />
              <p className="text-[13px] font-medium text-foreground">Couldn&apos;t generate today&apos;s briefing</p>
              <p className="text-[12px] text-muted-foreground">{error}</p>
              <button
                type="button"
                onClick={() => void load()}
                className="mt-1 inline-flex items-center gap-1.5 rounded-lg border border-border/60 bg-white px-3 py-1.5 text-[12px] font-medium text-foreground hover:bg-secondary"
              >
                <RefreshCw className="size-3.5" />
                Retry
              </button>
            </div>
          )}

          {status === "empty" && (
            <div className="flex flex-col items-center gap-2 px-4 py-8 text-center">
              <CheckCircle2 className="size-6 text-success" />
              <p className="text-[13px] font-medium text-foreground">You&apos;re all caught up</p>
              <p className="text-[12px] text-muted-foreground">
                {data?.summary || "Nothing needs your attention right now."}
              </p>
            </div>
          )}

          {status === "success" && data && (
            <div className="space-y-4">
              <p className="text-[13px] leading-relaxed text-foreground">{data.summary}</p>

              <ol className="space-y-3">
                {data.workflow.map((entry, idx) => {
                  const styles = KIND_STYLES[entry.kind]
                  const badgeLabel = entry.kind === "insight" ? "!" : String(idx + 1)
                  const clickable = entry.item_ids.length > 0 && itemsById.has(entry.item_ids[0])
                  return (
                    <li key={`${entry.kind}-${idx}`} className="flex items-start gap-3">
                      <span
                        className={cn(
                          "mt-0.5 flex size-6 shrink-0 items-center justify-center rounded-full text-[12px] font-semibold",
                          styles.badge,
                        )}
                      >
                        {badgeLabel}
                      </span>
                      <div className="min-w-0 flex-1">
                        <p className="text-[10.5px] font-semibold uppercase tracking-wide text-muted-foreground/80">
                          {entry.label}
                        </p>
                        <button
                          type="button"
                          disabled={!clickable}
                          onClick={() => goToEntry(entry)}
                          className={cn(
                            "mt-0.5 block text-left text-[13px] font-medium leading-snug text-foreground",
                            clickable && "hover:text-primary hover:underline underline-offset-2",
                          )}
                        >
                          {entry.title}
                        </button>
                        {entry.detail && (
                          <p className="mt-0.5 text-[12px] leading-relaxed text-muted-foreground">{entry.detail}</p>
                        )}
                      </div>
                    </li>
                  )
                })}
              </ol>

              <div className="flex items-center gap-2 border-t border-border/60 pt-3">
                <button
                  type="button"
                  disabled={!firstEntry}
                  onClick={() => goToEntry(firstEntry)}
                  className="inline-flex h-8 flex-1 items-center justify-center rounded-lg bg-navy px-3 text-[12.5px] font-semibold text-white transition-colors hover:bg-navy/90 disabled:opacity-50"
                >
                  Start with #1
                </button>
                <button
                  type="button"
                  disabled={!batchEntry}
                  onClick={() => {
                    if (!batchEntry) return
                    goToEntry(batchEntry)
                    toast.message("Opened the first batched item — approve each, then move to the next.")
                  }}
                  className="inline-flex h-8 items-center justify-center rounded-lg border border-border/60 bg-white px-3 text-[12.5px] font-medium text-foreground transition-colors hover:bg-secondary disabled:opacity-50"
                >
                  Approve the batch
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
