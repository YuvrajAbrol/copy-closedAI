"""Daily briefing agent: AI summary + ranked "suggested workflow" for Intake.

Combines whatever open items the frontend currently has on screen with live
backend aggregates (Cosmos counts of incomplete onboarding, open tickets,
active applicants) and asks the LLM to produce a short summary plus a
prioritized workflow. If no LLM key is configured, or the LLM call/parse
fails for any reason, falls back to a deterministic ranking computed from
the same real items — the ranking is always derived from actual data, never
hard-coded copy.
"""

from __future__ import annotations

import json
import logging
from collections import Counter, defaultdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from agents.runtime import llm_complete
from core.config import get_settings
from tools.azure_cosmos import get_dashboard_summary

logger = logging.getLogger(__name__)

URGENCY_WEIGHT = {"urgent": 4, "high": 3, "normal": 2, "low": 1}
DISPOSITION_WEIGHT = {"human": 3, "assist": 2, "auto": 1}

MAX_ITEMS_FOR_PROMPT = 40
MAX_WORKFLOW_ENTRIES = 6

_KIND_LABELS = {
    "priority": "Do this first",
    "batch": "Batch these",
    "cluster": "Same root cause",
    "insight": "Pattern worth knowing",
}

SYSTEM_PROMPT = """You are the HR Copilot's daily-briefing assistant. You are given the \
HR user's currently open intake items (support tickets, onboarding/offboarding events, \
policy questions, leave requests, etc.) plus live counts from the backend (incomplete \
onboarding, open helpdesk tickets, active applicants).

Write a short, concrete daily briefing that helps the HR user decide what to work on \
first today. Return STRICT JSON only, no markdown, no prose outside the JSON, matching \
exactly this shape:

{
  "summary": "one or two plain sentences summarizing today's open workload",
  "workflow": [
    {
      "kind": "priority" | "batch" | "cluster" | "insight",
      "title": "short, specific title",
      "detail": "one sentence explaining the reasoning",
      "item_ids": ["<ids from the provided list only>"]
    }
  ]
}

Rules:
- Ground every claim ONLY in the items and counts provided. Never invent ids, names, dates or numbers.
- item_ids must be drawn only from the ids listed in the input. Omit item_ids for a pure "insight" entry if it isn't about specific items.
- Exactly one "priority" entry: the single most time-critical/urgent item overall (weigh urgency, due date, and whether it needs human judgement).
- Use "batch" for a group of 2+ items that are all low-effort approvals of the same kind (e.g. copilot-drafted items awaiting sign-off).
- Use "cluster" when 2+ items share the same underlying ambiguity/root cause (e.g. same cluster_id) and resolving one answers the others.
- Use at most one "insight" entry noting a trend across topics/categories or the backend counts, only if something genuinely stands out.
- At most 6 entries total, ordered by importance. Keep titles and details concise.
"""


def _fmt_items_for_prompt(items: List[Dict[str, Any]]) -> str:
    lines = []
    for it in items[:MAX_ITEMS_FOR_PROMPT]:
        snippet = str(it.get("snippet") or "")[:140]
        lines.append(
            f"- id={it.get('id')!s} subject={it.get('subject')!r} urgency={it.get('urgency')!s} "
            f"disposition={it.get('disposition')!s} due={it.get('due')!r} "
            f"age_minutes={it.get('age_minutes')!s} cluster_id={it.get('cluster_id')!s} "
            f"topic={it.get('topic')!r} snippet={snippet!r}"
        )
    return "\n".join(lines)


def _score_item(it: Dict[str, Any]) -> float:
    urgency = URGENCY_WEIGHT.get(str(it.get("urgency") or "").lower(), 1)
    disposition = DISPOSITION_WEIGHT.get(str(it.get("disposition") or "").lower(), 1)
    age = float(it.get("age_minutes") or 0)
    due = str(it.get("due") or "").lower()
    due_boost = 3 if "today" in due else 2 if "tomorrow" in due else 0
    return urgency * 10 + disposition * 4 + due_boost * 3 + min(age / 60.0, 6.0)


def _heuristic_workflow(items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    open_items = [it for it in items if str(it.get("state")) != "handled" and it.get("id")]
    if not open_items:
        return []
    ranked = sorted(open_items, key=_score_item, reverse=True)
    workflow: List[Dict[str, Any]] = []

    top = ranked[0]
    reason_bits = [f"{str(top.get('urgency') or 'normal').capitalize()} urgency"]
    if top.get("due"):
        reason_bits.append(f"due {top.get('due')}")
    if top.get("disposition") == "human":
        reason_bits.append("needs your judgement")
    workflow.append(
        {
            "kind": "priority",
            "label": _KIND_LABELS["priority"],
            "title": str(top.get("subject") or top.get("id")),
            "detail": ", ".join(reason_bits) + ".",
            "item_ids": [top.get("id")],
        }
    )

    batchable = [it for it in ranked[1:] if str(it.get("disposition")) == "assist"][:4]
    if len(batchable) >= 2:
        workflow.append(
            {
                "kind": "batch",
                "label": _KIND_LABELS["batch"],
                "title": f"{len(batchable)} drafted items just need a review + approve",
                "detail": "Copilot already prepared these — batch through them together.",
                "item_ids": [b.get("id") for b in batchable],
            }
        )

    by_cluster: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for it in ranked:
        if str(it.get("disposition")) == "human" and it.get("cluster_id"):
            by_cluster[str(it["cluster_id"])].append(it)
    for group in by_cluster.values():
        if len(group) >= 2:
            ids = ", ".join(str(g.get("id")) for g in group)
            workflow.append(
                {
                    "kind": "cluster",
                    "label": _KIND_LABELS["cluster"],
                    "title": f"{len(group)} items trace to the same ambiguity ({ids})",
                    "detail": "Decide once and apply the answer to all of them.",
                    "item_ids": [g.get("id") for g in group],
                }
            )
            break

    topic_counts: Counter = Counter()
    topic_items: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for it in open_items:
        key = str(it.get("topic") or it.get("cluster_id") or "").split("·")[0].strip()
        if not key:
            continue
        topic_counts[key] += 1
        topic_items[key].append(it)
    if topic_counts:
        topic, count = topic_counts.most_common(1)[0]
        if count >= 3:
            workflow.append(
                {
                    "kind": "insight",
                    "label": _KIND_LABELS["insight"],
                    "title": f"{topic} accounts for {count} of today's open items",
                    "detail": "May be worth a proactive note or a policy clarification.",
                    "item_ids": [it.get("id") for it in topic_items[topic][:5]],
                }
            )

    return workflow[:MAX_WORKFLOW_ENTRIES]


def _heuristic_summary(items: List[Dict[str, Any]]) -> str:
    open_items = [it for it in items if str(it.get("state")) != "handled"]
    if not open_items:
        return "Nothing needs your attention right now — the queue is clear."
    needs_judgement = sum(1 for it in open_items if str(it.get("disposition")) == "human")
    tail = f", {needs_judgement} needing your judgement" if needs_judgement else ""
    plural = "" if len(open_items) == 1 else "s"
    return f"You have {len(open_items)} open item{plural}{tail}. Here's how I'd work through them."


def _validate_workflow(raw: Any, valid_ids: set) -> Optional[List[Dict[str, Any]]]:
    if not isinstance(raw, list):
        return None
    out: List[Dict[str, Any]] = []
    for entry in raw[:MAX_WORKFLOW_ENTRIES]:
        if not isinstance(entry, dict):
            continue
        kind = str(entry.get("kind") or "").strip().lower()
        if kind not in _KIND_LABELS:
            continue
        title = str(entry.get("title") or "").strip()
        if not title:
            continue
        raw_ids = entry.get("item_ids") or []
        if not isinstance(raw_ids, list):
            raw_ids = []
        item_ids = [i for i in raw_ids if isinstance(i, str) and i in valid_ids]
        out.append(
            {
                "kind": kind,
                "label": str(entry.get("label") or "").strip() or _KIND_LABELS[kind],
                "title": title[:160],
                "detail": str(entry.get("detail") or "").strip()[:280],
                "item_ids": item_ids,
            }
        )
    return out or None


def _extract_json(text: str) -> Optional[Dict[str, Any]]:
    text = (text or "").strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end == -1 or end <= start:
        return None
    try:
        return json.loads(text[start : end + 1])
    except json.JSONDecodeError:
        return None


async def generate_daily_briefing(items: List[Dict[str, Any]], user_id: str = "") -> Dict[str, Any]:
    """Return {summary, workflow, open_count, needs_judgement_count, counts, source, generated_at}."""
    items = items or []
    valid_ids = {str(it.get("id")) for it in items if it.get("id")}
    open_items = [it for it in items if str(it.get("state")) != "handled"]

    try:
        counts = get_dashboard_summary()
    except Exception:
        logger.exception("dashboard summary unavailable for briefing")
        counts = {}

    result: Dict[str, Any] = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "open_count": len(open_items),
        "needs_judgement_count": sum(1 for it in open_items if str(it.get("disposition")) == "human"),
        "counts": counts,
        "source": "heuristic",
    }

    if not open_items:
        result["summary"] = _heuristic_summary(items)
        result["workflow"] = []
        return result

    settings = get_settings()
    used_llm = False
    if settings.openai_api_key:
        try:
            prompt = (
                f"Backend counts (incomplete_onboarding, open_tickets, active_applicants): "
                f"{json.dumps(counts, default=str)}\n\n"
                f"Open intake items ({len(open_items)} total, most recent state):\n"
                f"{_fmt_items_for_prompt(open_items)}"
            )
            response = await llm_complete(
                [
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": prompt},
                ],
                stream=False,
            )
            content = response.choices[0].message.content or ""
            parsed = _extract_json(content)
            if parsed:
                workflow = _validate_workflow(parsed.get("workflow"), valid_ids)
                summary = str(parsed.get("summary") or "").strip()
                if workflow and summary:
                    result["summary"] = summary[:400]
                    result["workflow"] = workflow
                    result["source"] = "llm"
                    used_llm = True
        except Exception:
            logger.exception("LLM briefing generation failed for user_id=%s; using heuristic fallback", user_id)

    if not used_llm:
        result["summary"] = _heuristic_summary(items)
        result["workflow"] = _heuristic_workflow(items)

    return result
