"""Global HR dashboard summary for the Side Canvas, and the AI daily briefing."""

from __future__ import annotations

from typing import List

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from agents.insights import generate_daily_briefing
from core.security.jwt_auth import verify_jwt
from tools.azure_cosmos import get_dashboard_summary

router = APIRouter(prefix="/dashboard", tags=["dashboard"])


@router.get("/summary")
async def dashboard_summary(user: dict = Depends(verify_jwt)):
    """Lightweight Cosmos counts for onboarding, helpdesk, and ATS."""
    _ = user
    return get_dashboard_summary()


class BriefingItem(BaseModel):
    """One open item currently visible on the Intake page."""

    id: str
    subject: str = ""
    urgency: str = "normal"
    disposition: str = "human"
    due: str = ""
    age_minutes: int = 0
    cluster_id: str = ""
    state: str = "new"
    topic: str = ""
    snippet: str = ""


class BriefingRequest(BaseModel):
    items: List[BriefingItem] = Field(default_factory=list)


@router.post("/briefing")
async def dashboard_briefing(body: BriefingRequest, user: dict = Depends(verify_jwt)):
    """AI summary + prioritized "Suggested Workflow for Today", ranked from real data.

    Takes the intake items currently on screen, cross-references live backend
    counts (Cosmos), and asks the LLM to rank what the HR user should work on
    first. Falls back to a deterministic ranking of the same items if no LLM
    key is configured or the call/parse fails.
    """
    items = [i.model_dump() for i in body.items]
    return await generate_daily_briefing(items, user_id=str(user.get("user_id") or ""))
